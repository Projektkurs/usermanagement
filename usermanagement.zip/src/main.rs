#![feature(linked_list_cursors)]
use rocket::{
    fairing::AdHoc,
    fs::{relative, FileServer, NamedFile},
    response::Redirect,
};
use rocket_db_pools::Database;
mod database;
mod room;
mod test;
mod user;
use database::MainDatabase;
#[macro_use]
extern crate rocket;
#[launch]
fn rocket() -> _ {
    rocket::build()
        .attach(MainDatabase::init())
        .attach(AdHoc::try_on_ignite(
            "Create collection indexes",
            database::create_indexes,
        ))
}
