use chrono::{DateTime, Local};
use serde::*;
use std::collections::LinkedList;
use uuid::Uuid;

#[derive(Default, Debug, Serialize, Deserialize)]
pub struct Event<'a> {
    id: u128,
    booker_id: &'a str,
    headline: &'a str,
    description: &'a str,

    start: DateTime<Local>,
    stop: DateTime<Local>,
}
impl<'a> Event<'a> {
    fn create(
        booker_id: &'a str,
        headline: &'a str,
        description: &'a str,
        start: DateTime<Local>,
        stop: DateTime<Local>,
    ) -> Option<Self> {
        if start <= stop || booker_id == "" {
            return None;
        }
        Some(Event {
            id: Uuid::new_v4().as_u128(),
            booker_id,
            headline,
            description,
            start,
            stop,
        })
    }
}

#[derive(Default, Debug, Serialize, Deserialize)]
pub struct Room<'a> {
    name: &'a str,
    #[serde(borrow)]
    events: LinkedList<Event<'a>>,
}
impl<'a> Room<'a> {
    pub fn create(name: &'a str) -> Self {
        Room {
            name,
            events: LinkedList::new(),
        }
    }
    pub fn could_accomodate(&self, event: Event) -> bool {
        for currentevent in &self.events {
            if !(currentevent.start >= event.stop || currentevent.stop <= event.start) {
                return false;
            }
            if currentevent.stop <= event.start {
                return true;
            }
        }
        true
    }
    pub fn add_event(&mut self, event: Event<'a>) -> bool {
        let cursor = &mut self.events.cursor_front_mut();
        loop {
            if let Some(currentevent) = &cursor.current() {
                if !(currentevent.start >= event.stop || currentevent.stop <= event.start) {
                    return false;
                }
                if currentevent.stop <= event.start {
                    cursor.insert_after(event);
                    return true;
                }
            } else {
                self.events.push_back(event);
                return true;
            }
            cursor.move_next();
        }
    }
    /// returns true if successfull
    pub fn remove_event(&mut self, event_id: u128) -> bool {
        let cursor = &mut self.events.cursor_front_mut();
        loop {
            if let Some(currentevent) = &cursor.current() {
                if currentevent.id == event_id {
                    cursor.remove_current();
                    return true;
                }
            } else {
                return false;
            }
            cursor.move_next();
        }
    }
}
#[cfg(test)]
mod tests {
    use chrono::Days;

    use super::*;
    #[test]
    fn test_add_event_on_empty() {
        let mut room = Room::default();
        let event = Event::default();
        assert!(room.add_event(event));
    }
    #[test]
    #[should_panic]
    fn test_add_event_overlap() {
        let mut room = Room::default();
        let mut event = Event::default();
        event.start = event.start.checked_sub_days(Days::new(1)).unwrap();
        event.stop = event.stop.checked_add_days(Days::new(1)).unwrap();
        println!("first event:{:?}", event);
        assert!(room.add_event(event));
        let event = Event::default();
        println!("second event:{:?}", event);
        assert!(room.add_event(event));
    }
    #[test]
    /// As one event could start at 12 while another stops at 12, partial overlap is allowed.
    fn test_add_event_partial_overlap() {
        let mut room = Room::default();
        let mut event = Event::default();
        event.start = event.start.checked_sub_days(Days::new(1)).unwrap();
        println!("first event:{:?}", event);
        assert!(room.add_event(event));
        let mut event = Event::default();
        event.stop = event.stop.checked_add_days(Days::new(1)).unwrap();
        println!("second event:{:?}", event);
        assert!(room.add_event(event));
    }

    #[test]
    #[should_panic]
    fn test_remove_event_on_empty() {
        let mut room = Room::default();
        assert!(room.remove_event(0));
    }
    #[test]
    #[should_panic]
    fn test_remove_event_unknown_id() {
        let mut room = Room::default();
        assert!(room.add_event(Event::default()));
        assert!(room.remove_event(1));
    }
    #[test]
    fn test_remove_event_normal() {
        let mut room = Room::default();
        assert!(room.add_event(Event::default()));
        room.remove_event(0);
        assert!(room.events.is_empty());
    }
}
