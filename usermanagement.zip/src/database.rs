use mongodb::{bson::doc, options::ClientOptions, Client};
use mongodb::{options::IndexOptions, IndexModel};
use rocket::fairing;
use rocket::{Build, Rocket};
pub use rocket_db_pools::Connection;
use rocket_db_pools::{mongodb, Database};
use serde::{Deserialize, Serialize};
use crate::user::User;
use crate::room::Room;

#[derive(Database)]
#[database("main_db")]
pub struct MainDatabase(mongodb::Client);

pub trait DatabaseUtils {
    fn db(&self) -> mongodb::Database;

    fn user_collection(&self) -> mongodb::Collection<User>;

    fn room_collection(&self) -> mongodb::Collection<Room>;

    fn create_example_users(&self) -> Option<&Self>;
}

impl DatabaseUtils for mongodb::Client {
    fn db(&self) -> mongodb::Database {
        self.database("helper:Paper")
    }

    fn user_collection(&self) -> mongodb::Collection<User> {
        self.db().collection::<User>("users")
    }
    fn room_collection(&self) -> mongodb::Collection<Room> {
        self.db().collection::<Room>("rooms")
    }
    fn create_example_users(&self) -> Option<&Self> {
        Some(&self)
    }
}

/*#[derive(Default, Clone, Debug, Deserialize, Serialize)]
pub struct User {
    username: String,
    password: String,
    admin: bool,

    firstname: Option<String>,
    surname: Option<String>,
}*/

/*impl User {
    pub fn new<S: Into<String>>(username: S, password: S) -> User {
        User {
            username: username.into(),
            password: password.into(),
            admin: false,
        }
    }

    pub fn name(&self) -> &str {
        &self.username
    }

    pub fn password_hash(&self) -> &str {
        &self.password
    }

    pub fn admin(&self) -> bool {
        self.admin
    }
}*/

pub async fn create_indexes(rocket: Rocket<Build>) -> fairing::Result {
    println!("setting up db");
    if let Some(db) = MainDatabase::fetch(&rocket) {
        //let filter = doc!{};

        //println!("{:?}",db.0.users_coll().find_one(filter, None).await);
        db.0.user_collection()
            .create_index(
                IndexModel::builder()
                    .keys(doc! {"username": 1})
                    .options(IndexOptions::builder().unique(true).build())
                    .build(),
                None,
            )
            .await
            .ok()
            .unwrap();

        db.0.room_collection()
            .create_index(
                IndexModel::builder()
                    .keys(doc! {"id": 1})
                    .options(IndexOptions::builder().unique(true).build())
                    .build(),
                None,
            )
            .await
            .ok()
            .unwrap();
        return Ok(rocket);
    } else {
        Err(rocket)
    }
}
