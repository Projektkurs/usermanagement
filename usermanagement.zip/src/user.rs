use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use rocket::form::Form;
use mongodb::{bson::doc, options::ClientOptions, Client};
use crate::database::{Connection, MainDatabase, DatabaseUtils};
use serde::*;

#[derive(Debug, Serialize, Deserialize)]
pub struct User {
    // todo: username as id
    //#[serde(rename = "_id")]
    username: String,
    password_hash: String,
    is_active: bool,
    // Permissions
    is_admin: bool,
    can_creat_users: bool,
    editable_rooms: Vec<String>, // saves name of the room
    // Personal information
    firstname: String,
    surname: String,
    email: Option<String>,
    phone_number: Option<String>, // String for setting prefix in brackets or +49
}

impl<'a> User {
    pub fn new(firstname: String, surname: String, password: String) -> Result<Self, &'a str> {
        if password == " " {
            return Err("Password cannot be empty");
        }
        let salt = SaltString::generate(&mut OsRng);
        let password_hash = Argon2::default().hash_password(password.as_bytes(), &salt).unwrap().to_string();
        let user = Ok(User {
            username: format!("{}.{}", surname, firstname),
            password_hash,
            is_active: true,
            is_admin: false,
            can_creat_users: false,
            editable_rooms: Vec::new(),
            firstname: firstname,
            surname: surname,
            email: None,
            phone_number: None,
        });
        user.validate_first_name().validate_surname()
    }
    async fn insert(&self,db:mongodb::Client) -> Option<()>{
        if let Some(_) = User::getfromdb(&self.username,db.clone()).await{
            return None
        }
        //todo
        if let Ok(_user) = db.user_collection().insert_one(self, None).await{
            return Some(())
        }else{
            return None
        }
    }
    async fn getfromdb(username: &str, db:mongodb::Client) -> Option<Self>{
        db.user_collection().find_one(doc!{"username": username}, None).await.unwrap()
    }
    async fn login(username: &str, password: String, db:mongodb::Client) -> Option<Self>{
        let user = db.user_collection().find_one(doc!{"username": username}, None).await.unwrap();
        if let Some(user) = user{
            let passwordhash = PasswordHash::new(&user.password_hash).unwrap();

            if let Ok(_) = Argon2::default().verify_password(password.as_bytes(), &passwordhash ){
                return Some(user)
            }else{
                return None
            }
        }else{
            return None
        }
    }
}

mod tests {
    use super::*;
    /// create some demo users on the life database.
    #[tokio::test]
    async fn test_usercreation(){
        let client =  Client::with_uri_str("mongodb://localhost:27017").await.unwrap();
        let users = &mut Vec::new();
        users.push(User::new(format!("Max"), format!("Mustermann"), format!("1234")).unwrap());
        users.push(User::new(format!("Anna"), format!("Müller"), format!("5678")).unwrap());
        users.push(User::new(format!("Hans"), format!("Schmidt"), format!("9012")).unwrap());
        users.push(User::new(format!("Maria"), format!("Gonzalez"), format!("3456")).unwrap());
        users.push(User::new(format!("Thomas"), format!("Lee"), format!("7890")).unwrap());
        users.push(User::new(format!("Sarah"), format!("Kim"), format!("2345")).unwrap());
        users.push(User::new(format!("David"), format!("Garcia"), format!("6789")).unwrap());
        users.push(User::new(format!("Julia"), format!("Chen"), format!("0123")).unwrap());
        users.push(User::new(format!("Peter"), format!("Jürgensen"), format!("4567")).unwrap());
        users.push(User::new(format!("Lisa"), format!("Wong"), format!("8901")).unwrap());

        let insertfuture: &mut Vec<std::pin::Pin<Box<dyn std::future::Future<Output = Option<()>>>>> = &mut Vec::new(); 
        for user in users{
            insertfuture.push(Box::pin(user.insert(client.clone())));
        }
        for future in insertfuture{
            future.await;
        }
    }
}
trait UserValidate<'a>
where
    Self: Sized,
{
    fn validate_first_name(self) -> Self;
    fn validate_surname(self) -> Self;
}
impl<'a> UserValidate<'a> for Result<User, &'a str> {
    // TODO look for a way to do normal error propagation while holding onto the ownership
    fn validate_first_name(self) -> Self {
        if self.is_err(){
            return self;
        }
        if self.as_ref().unwrap().firstname == "" {
            return Err("the first name cannot be empty");
        }
        self
    }
    fn validate_surname(self) -> Self {
        if self.is_err(){
            return self;
        }
        if self.as_ref().unwrap().surname == "" {
            return Err("the surname cannot be empty");
        }
        self
    }
}

#[derive(Debug, FromForm)]
struct UserData<'r>{
    username: &'r str,
    password: &'r str
}
#[derive(Debug, FromForm)]
struct CreateUserForm<'r> {
    userdata: UserData<'r>,
    firstname: &'r str,
    surname: &'r str,
    password: &'r str,
}
// todo: get access rights
// add_room
#[post("/create_user", data = "<form>")]
fn create_user(form: Form<CreateUserForm<'_>>){

}
/*#[derive(Serialize, Deserialize)]
struct UserSession {
    id: u64,
    username: String,
    salt: String,
}
*/