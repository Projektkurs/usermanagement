use crate::{database::{self,DatabaseUtils},event::{self,Event},user,MainDatabase};
use bson::doc;
use bson::oid::ObjectId;
use bson::Document;
use chrono::{DateTime, Local};
use mongodb::results::UpdateResult;
use mongodb::Client;
use rocket::form::Form;
use rocket_db_pools::Connection;
use serde::*;
use std::collections::HashMap;
use std::collections::LinkedList;
use std::process::id;
use rocket::Route;
#[derive(Default, Debug, Serialize, Deserialize)]
pub struct Room {
    #[serde(rename = "_id")]
    id: ObjectId,
    name: String,
    events: LinkedList<Event>,
    layouts: Vec<ObjectId>,
    layout_values: HashMap<String, String>,
    owner: Option<ObjectId>,
    description: Option<String>,
}
impl Room {
    /// creates a new Room with a new Object id.
    /// owner and description are left empty
    pub fn create(name: String) -> Self {
        Room {
            id: ObjectId::new(),
            name,
            events: LinkedList::new(),
            layouts: Vec::new(),
            layout_values: HashMap::new(),
            owner: None,
            description: None,
        }
    }
    /// looks up, wether [Room] could accomodate the given event
    /// accomodate means in this context that there is no overlaping event in
    /// the time slot. The event can parital overlap with another event, e.g. one event can end at 12:00 while the other starts at 12:00
    pub fn could_accomodate(&self, event: Event) -> bool {
        for currentevent in &self.events {
            if !(currentevent.start().timestamp() >= event.stop().timestamp()
                || currentevent.stop().timestamp() <= event.start().timestamp())
            {
                return false;
            }
            if currentevent.stop().timestamp() <= event.start().timestamp() {
                return true;
            }
        }
        true
    }
    pub fn add_event(&mut self, event: Event) -> Option<()> {
        let cursor = &mut self.events.cursor_front_mut();
        if let Some(currentevent) = &cursor.current() {
            if currentevent.start().timestamp() >= event.stop().timestamp() {
                cursor.insert_before(event);
                return Some(());
            }
        }
        loop {
            if let Some(currentevent) = &cursor.current() {
                println!("{:?}", currentevent);
                if !(currentevent.start().timestamp() >= event.stop().timestamp()
                    || currentevent.stop().timestamp() <= event.start().timestamp())
                {
                    return None;
                }
                if currentevent.stop().timestamp() <= event.start().timestamp() {
                    cursor.insert_after(event);
                    return Some(());
                }
                cursor.move_next();
            } else {
                //return None;
                self.events.push_back(event);
                return Some(());
            }
        }
    }
    /// returns true if successfull
    pub fn remove_event(&mut self, event_id: bson::oid::ObjectId) -> bool {
        let cursor = &mut self.events.cursor_front_mut();
        loop {
            if let Some(currentevent) = &cursor.current() {
                if currentevent.id() == event_id {
                    cursor.remove_current();
                    return true;
                }
            } else {
                return false;
            }
            cursor.move_next();
        }
    }
    async fn update(&mut self, db: &mongodb::Client) -> Result<(), database::Error> {
        let filter = doc! {"_id": self.id};
        let update_doc = doc! {"$set": bson::to_document(self)?};
        let update_result = db
            .room_collection()
            .update_one(filter, update_doc, None)
            .await?;
        if update_result.modified_count > 0 {
            Ok(())
        } else {
            Err(database::Error::NoUpdate)
        }
    }
    async fn insert(&self, db: &mongodb::Client) -> Option<()> {
        if self.isindb(db).await {
            return None;
        }
        db.room_collection().insert_one(self, None).await.ok()?;
        Some(())
    }
    async fn getfromdb_name(name: &str, db: &mongodb::Client) -> Option<Room> {
        db.room_collection()
            .find_one(doc! {"name": name}, None)
            .await
            .ok()?
    }
    async fn getfromdb_id(id: &ObjectId, db: &mongodb::Client) -> Option<Room> {
        db.room_collection()
            .find_one(doc! {"_id": id}, None)
            .await
            .ok()?
    }
    async fn isindb(&self, db: &mongodb::Client) -> bool {
        if let Some(_room) = Room::getfromdb_id(&self.id, &db).await {
            return true;
        }
        false
    }
}
#[derive(Debug,FromForm)]
struct CreateDeleteForm<'r>{
    userdata: user::UserData<'r>,
    name: &'r str,
}
#[post("/create", data = "<form>")]
async fn create(form: Form<CreateDeleteForm<'_>>, db: Connection<MainDatabase>) -> Option<()> {
    println!("get user");
    let user = user::User::login(
        form.userdata.username,
        String::from(form.userdata.password),
        &*db,
    )
    .await
    .ok()?;
    println!("got user");
    if !user.can_create_rooms() || Room::getfromdb_name(form.name, &db).await.is_some(){
        println!("user cannot create rooms");
        return None
    }
    let room = Room::create(String::from(form.name));
    println!("insert user");
    room.insert(&db).await?;
    Some(())
}
#[post("/delete", data = "<form>")]
async fn delete(form: Form<CreateDeleteForm<'_>>, db: Connection<MainDatabase>) -> Option<()> {
    println!("get user");
    let user = user::User::login(
        form.userdata.username,
        String::from(form.userdata.password),
        &*db,
    )
    .await
    .ok()?;
    println!("got user");
    let room= Room::getfromdb_name(form.name,&db).await?;
    if !user.can_edit_room(&room.id) {
        println!("cannot delete rooms");
        return None
    }
    db.room_collection().delete_one(doc!{"_id": room.id}, None).await.ok()?;
    println!("insert user");
    Some(())
}
#[derive(Debug, FromForm)]
struct CreateEventForm<'a> {
    userdata: user::UserData<'a>,
    room_name: Option<String>,
    room_id: Option<String>,
    booker_id: String,
    headline: String,
    description: Option<String>,
    start: String,
    stop: String,
}

#[post("/get?<name>", data = "<form>")]
async fn get(
    name: &str,
    form: Form<user::UserData<'_>>,
    db: Connection<MainDatabase>,
) -> Option<String> {
    println!("room:{}",name);
    let user = &user::User::login(form.username, String::from(form.password), &*db)
        .await
        .ok()?;
    println!("search for room");
    let room = Room::getfromdb_name(name, &*db).await?;
    if !user.can_edit_room(&room.id){
        println!("cannot edit rooms");
        return None;
    }
    Some(rocket::serde::json::to_string(&room).ok()?)
}

#[post("/add_event", data = "<form>")]
async fn add_event(form: Form<CreateEventForm<'_>>, db: Connection<MainDatabase>) -> Option<()> {
    let user = user::User::login(
        form.userdata.username,
        String::from(form.userdata.password),
        &*db,
    )
    .await
    .ok()?;
    let mut room = if let Some(room_id) = &form.room_id{
        let id = rocket::serde::json::from_str::<ObjectId>(&room_id).ok()?;
        Room::getfromdb_id(&id, &db).await?
    }else{
        Room::getfromdb_name(&form.room_name.clone()?, &db).await?
    };
    let start = rocket::serde::json::from_str::<DateTime<Local>>(&form.start).ok()?;
    let stop = rocket::serde::json::from_str::<DateTime<Local>>(&form.stop).ok()?;
    // way to do this without cloning?
    let event = event::Event::create(
        form.booker_id.clone(),
        form.headline.clone(),
        form.description.clone(),
        start,
        stop,
    )?;
    if !user.can_edit_room(&room.id){
        return None;
    }
    room.add_event(event)?;
    room.update(&db).await.ok()?;
    Some(())
}


pub fn routes() -> Vec<Route> {
    routes![create,delete,get,add_event]
}
#[cfg(test)]
mod tests {
    use super::*;
    use chrono::{ Local, Timelike};
    #[tokio::test]
    async fn event_creation() {
        let db = Client::with_uri_str("mongodb://localhost:27017")
            .await
            .expect("Connection to mongodb could not be established");
        let room_opt = Room::getfromdb_name("test-room", &db).await;
        let mut room = if let Some(room) = room_opt {
            room
        } else {
            println!("room not found");
            let room = Room::create(String::from("test-room"));
            room.insert(&db).await.expect("insertion failed");
            room
        };
        //let start= Local.timestamp_nanos(0);
        let start = Local::now();
        let stop = start
            .with_minute(start.minute() + 1)
            .expect("failed just because it is HH:59, just rerun the test later");
        room.add_event(
            Event::create(
                String::from("fake-id"),
                String::from("headline"),
                None,
                start,
                stop,
            )
            .expect("could not generate event"),
        )
        .expect("failed to add event. Note this test can just run once every minute as it adds an Event that lasts one minute");
        room.update(&db).await.expect("room could not be updated");
    }
}
