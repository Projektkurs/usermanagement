use crate::event::Event;
use bson::oid::ObjectId;
use chrono::{DateTime,Local};
use serde::{Deserialize, Serialize};
#[derive(Default, Debug, Serialize, Deserialize)]
pub struct Epaper {
    #[serde(rename = "_id")]
    id: ObjectId,
    name: String,
    activelayout_layout: ObjectId,
    update_rate: DateTime<Local>,
    room: Option<ObjectId>,

}
