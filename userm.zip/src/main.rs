//! main.rs - A Rocket backend for a Room Reservation
//!
//! Copyright 2023 by Ben Mattes Krusekamp <ben.krause05@gmail.com>
#![feature(linked_list_cursors)]
#![feature(let_chains)]
#![allow(dead_code)]
#![feature(async_fn_in_trait)]
use rocket::fairing::AdHoc;
use rocket_db_pools::Database;
mod database;
mod epaper;
mod event;
mod image;
mod layout;
mod room;
mod user;
use database::MainDatabase;
#[macro_use]
extern crate rocket;
#[launch]
fn rocket() -> _ {
    println!("{:?}", user::routes()[1].uri);
    rocket::build()
        .attach(database::MainDatabase::init())
        .attach(AdHoc::try_on_ignite(
            "Create collection indices",
            database::create_indices,
        ))
        .register("/", catchers![not_found])
        .mount("/", routes![status])
        .mount("/epaper", epaper::routes())
        .mount("/user", user::routes())
        .mount("/room", room::routes())
        .mount("/image", image::routes())
}

#[get("/status")]
async fn status() -> Option<&'static str> {
    Some("ok")
}
#[catch(404)]
fn not_found() -> String {
    String::from("")
}

#[macro_export]
macro_rules! debug_println {
    ($($rest:tt)*) => {
        if std::env::var("DEBUG").is_ok() {
            std::println!($($rest)*);
        }
    }
}
